package com.steven.android.listviewqiushiviewtype;

import java.util.List;
import java.util.Map;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class QiushiAdapter extends BaseAdapter {
	private Context	context	= null;
	private List<Map<String, String>> list	= null;
	private LayoutInflater	mInflater = null;
	
	public QiushiAdapter(Context context, List<Map<String, String>> list) {
		this.context = context;
		this.list = list;
		mInflater = (LayoutInflater) context
		                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}
	
	@Override
	public int getItemViewType(int position) {
		String image = getImageUrl(list.get(position).get("image"));
		if ("".equals(image)) {
			return 0;
		} else {
			return 1;
		}
	}
	
	@Override
	public int getViewTypeCount() {
		return 2;
	}
	
	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}
	
	@Override
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}
	
	@Override
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder0 mHolder0 = null;
		ViewHolder1 mHolder1 = null;
		
		int type = getItemViewType(position);
		
		if (convertView == null) {
			switch (type) {
				case 0:
					convertView = mInflater
					                .inflate(R.layout.item_listview_main0,
					                                parent,
					                                false);
					mHolder0 = new ViewHolder0(convertView);
					
					convertView.setTag(mHolder0);
					break;
				case 1:
					convertView = mInflater
					                .inflate(R.layout.item_listview_main1,
					                                parent,
					                                false);
					mHolder1 = new ViewHolder1(convertView);
					
					convertView.setTag(mHolder1);
					break;
			}
			
		} else {
			switch (type) {
				case 0:
					mHolder0 = (ViewHolder0) convertView
					                .getTag();
					break;
				case 1:
					mHolder1 = (ViewHolder1) convertView
					                .getTag();
			}
		}
		
		// 给viewHolder的控件赋值
		switch (type) {
			case 0:
				mHolder0.textView_item_content
				                .setText(((Map<String, String>) getItem(position))
				                                .get("content"));
				mHolder0.textView_item_login.setText(list.get(
				                position).get("login"));
				mHolder0.textView_item_commentscounts
				                .setText("评论数："
				                                + list.get(position)
				                                                .get("commentscounts"));
				break;
			case 1:
				mHolder1.textView_item_content
				                .setText(((Map<String, String>) getItem(position))
				                                .get("content"));
				mHolder1.textView_item_login.setText(list.get(
				                position).get("login"));
				mHolder1.textView_item_commentscounts
				                .setText("评论数："
				                                + list.get(position)
				                                                .get("commentscounts"));
				
				// 使用Glide框架加载图片
				final String imgUrl = getImageUrl(list
				                .get(position).get("image")
				                .toString());
				Glide.with(context)
				                .load(imgUrl)
				                .into(mHolder1.imageView_item_icon);
				
				mHolder1.imageView_item_icon
				                .setOnClickListener(new OnClickListener() {
					                
					                @Override
					                public void onClick(
					                                View view) {
						                // 点击看大图
						                Intent intent = new Intent();
						                intent.setClass(context,
						                                ShowpicActivity.class);
						                Bundle bundle = new Bundle();
						                bundle.putString(
						                                "imgUrl",
						                                imgUrl);
						                intent.putExtras(bundle);
						                context.startActivity(intent);
						                
					                }
				                });
				break;
		}
		
		return convertView;
	}
	
	class ViewHolder0 {
		private TextView	textView_item_content;
		private TextView	textView_item_login;
		private TextView	textView_item_commentscounts;
		
		public ViewHolder0(View convertView) {
			textView_item_content = (TextView) convertView
			                .findViewById(R.id.textView_item_content);
			textView_item_login = (TextView) convertView
			                .findViewById(R.id.textView_item_login);
			textView_item_commentscounts = (TextView) convertView
			                .findViewById(R.id.textView_item_commentscounts);
		}
	}
	
	class ViewHolder1 {
		private ImageView	imageView_item_icon;
		private TextView	textView_item_content;
		private TextView	textView_item_login;
		private TextView	textView_item_commentscounts;
		
		public ViewHolder1(View convertView) {
			imageView_item_icon = (ImageView) convertView
			                .findViewById(R.id.imageView_item_icon);
			textView_item_content = (TextView) convertView
			                .findViewById(R.id.textView_item_content);
			textView_item_login = (TextView) convertView
			                .findViewById(R.id.textView_item_login);
			textView_item_commentscounts = (TextView) convertView
			                .findViewById(R.id.textView_item_commentscounts);
		}
	}
	
	private String getImageUrl(String imageName) {
		if (imageName.indexOf('.') > 0) {
			StringBuilder sb = new StringBuilder();
			//
			String urlSecond = imageName.substring(3,
			                imageName.indexOf('.'));
			String urlFirst = "";
			switch (urlSecond.length()) {
				case 8:
					urlFirst = imageName.substring(3, 7);
					break;
				case 9:
					urlFirst = imageName.substring(3, 8);
					break;
			}
			sb.append("http://pic.qiushibaike.com/system/pictures/");
			sb.append(urlFirst);
			sb.append("/");
			sb.append(urlSecond);
			sb.append("/");
			sb.append("small/");
			sb.append(imageName);
			return sb.toString();
		} else {
			return "";
		}
	}
	
}
