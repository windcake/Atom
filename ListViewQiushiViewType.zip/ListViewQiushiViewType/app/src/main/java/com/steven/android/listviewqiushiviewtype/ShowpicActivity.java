package com.steven.android.listviewqiushiviewtype;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class ShowpicActivity extends Activity {
	private Context	  mContext	= this;
	private ImageView	imageView_showpic;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_showpic);
		
		initView();
		
		loadImage();
		
	}
	
	private void loadImage() {
		String imgUrl_small = getIntent().getExtras().getString(
		                "imgUrl");
		String imgUrl_medium = imgUrl_small.replace("small", "medium");
		
		Glide.with(mContext).load(imgUrl_medium)
		                .into(imageView_showpic);
		
	}
	
	private void initView() {
		imageView_showpic = (ImageView) findViewById(R.id.imageView_showpic);
		
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is
		// present.
		getMenuInflater().inflate(R.menu.showpic, menu);
		return true;
	}
	
}
