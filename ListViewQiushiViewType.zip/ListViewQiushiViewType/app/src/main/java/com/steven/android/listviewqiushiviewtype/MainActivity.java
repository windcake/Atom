package com.steven.android.listviewqiushiviewtype;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.view.Menu;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
	private Context mContext = this;
	private List<Map<String, String>> totalList	= new ArrayList<Map<String, String>>();
	private QiushiAdapter adapter = null;
	
	private ListView listView_main;
	private TextView textView_empty;
	
	private String urlString = "http://m2.qiushibaike.com/article/list/latest?page=1";
	
	private Handler	handler = new Handler();

	private int curPage = 1;

	private SwipeRefreshLayout swipeLayout_main;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		// 初始化UI控件
		initView();
		// 加载网络数据
		loadNetworkData();
	}
	
	private void loadNetworkData() {
		// TODO Auto-generated method stub
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// 网络访问
				try {
					ByteArrayOutputStream baos = new ByteArrayOutputStream();
					BufferedInputStream bis = null;
					URL url = new URL(urlString);
					HttpURLConnection httpConn = (HttpURLConnection) url
					                .openConnection();
					httpConn.setRequestMethod("GET");
					httpConn.setDoInput(true);
					httpConn.setDoOutput(false);
					
					if (httpConn.getResponseCode() == 200) {
						bis = new BufferedInputStream(
						                httpConn.getInputStream());
						int c = 0;
						byte[] buffer = new byte[8 * 1024];
						while ((c = bis.read(buffer)) != -1) {
							baos.write(buffer, 0, c);
							baos.flush();
						}
						String jsonString = baos
						                .toString();
						
						final List<Map<String, String>> list = jsonStringToList(jsonString);
//                      handler发回主线程
						handler.post(new Runnable() {
							@Override
							public void run() {
								
								totalList.clear();
								totalList.addAll(list);
								adapter.notifyDataSetChanged();
								swipeLayout_main.setRefreshing(false);
							}
						});
					}
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}

//	json解析成List
	private List<Map<String, String>> jsonStringToList(String jsonString) {
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();
		try {
			JSONObject jsonObject = new JSONObject(jsonString);
			JSONArray jsonArray_items = jsonObject
			                .getJSONArray("items");
			for (int i = 0; i < jsonArray_items.length(); i++) {
				
				JSONObject jsonObject_item = jsonArray_items
				                .getJSONObject(i);
				
				String content = jsonObject_item
				                .getString("content");
				String commentscounts = jsonObject_item
				                .getString("comments_count");
				String image = jsonObject_item
				                .getString("image");
				
				String login = "";
				JSONObject jsonObject_user = jsonObject_item
				                .optJSONObject("user");
				if (jsonObject_user == null) {
					login = "";
				} else {
					login = jsonObject_user
					                .getString("login");
				}
				
				Map<String, String> map = new HashMap<String, String>();
				map.put("content", content);
				map.put("commentscounts", commentscounts);
				map.put("image", image);
				map.put("login", login);
				list.add(map);
			}
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	private void initView() {
		swipeLayout_main = (SwipeRefreshLayout) findViewById(R.id.swipeLayout_main);
		listView_main = (ListView) findViewById(R.id.listView_main);
		textView_empty = (TextView) findViewById(R.id.textView_empty);
		
		adapter = new QiushiAdapter(mContext, totalList);
		listView_main.setAdapter(adapter);
		listView_main.setEmptyView(textView_empty);



		// 设置动画颜色
		swipeLayout_main.setColorSchemeColors(Color.RED, Color.BLUE, Color.GREEN);

		// 设置刷新监听
		swipeLayout_main.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
			@Override
			public void onRefresh() {
				curPage = 1;
				loadNetworkData();
			}
		});

	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is
		// present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
}
